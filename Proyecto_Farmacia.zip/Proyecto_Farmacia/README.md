# Proyect_Farmacia
Desktop project, made with the programming language and the NetBeands Apache IDE, uses the MySQL database manager.

link download database => https://mega.nz/folder/D3ZWQZ4K#6Mt1MdAxqBaZU6KjMQWTCw

link dowload JarFiles => https://mega.nz/folder/T6BUjbJC#Dr7bFungzv-j3047K4Stqw

Documentation 
https://universityproyectx.blogspot.com/2021/09/sistema-de-ventas-de-una-farmacia.html


![Img](https://github.com/SakNoelCode/Imagenes_Proyectos/blob/master/Captura%20de%20pantalla%20(3187).png)
![Img](https://github.com/SakNoelCode/Imagenes_Proyectos/blob/master/Captura%20de%20pantalla%20(3188).png)
