package Vista;

import Conexion.ConexionBD;
import Metodos.Metodos_User;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;


public class AdministrarPerfil extends javax.swing.JInternalFrame {

    String path = "";

    int nums = 0;

   
    public AdministrarPerfil() {
        initComponents();

        setBounds(0, 0, 715, 595);
    }
    Metodos_User metodos = new Metodos_User();


    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        btnImagen = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtApellidos = new javax.swing.JTextField();
        txtId = new javax.swing.JTextField();
        txtNombres = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtDni = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtNomUsuario = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtClave = new javax.swing.JTextField();
        txtTipoUser = new javax.swing.JTextField();
        txtEstado = new javax.swing.JTextField();
        jSeparator11 = new javax.swing.JSeparator();
        jSeparator12 = new javax.swing.JSeparator();
        jSeparator13 = new javax.swing.JSeparator();
        jSeparator14 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        jLabel10 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        btnModificar = new javax.swing.JButton();
        btnImprimir = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        jpAdmin = new keeptoo.KGradientPanel();
        txtImagen = new javax.swing.JLabel();
        jpInvitado = new keeptoo.KGradientPanel();
        txtImagen1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(58, 159, 171));
        setClosable(true);
        setIconifiable(true);
        setMinimumSize(new java.awt.Dimension(76, 100));
        setPreferredSize(new java.awt.Dimension(715, 595));
        getContentPane().setLayout(null);

        btnImagen.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnImagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/busc.png"))); // NOI18N
        btnImagen.setText("Seleccionar Imagen");
        btnImagen.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnImagen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImagenActionPerformed(evt);
            }
        });
        getContentPane().add(btnImagen);
        btnImagen.setBounds(440, 300, 210, 37);

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(58, 159, 171), 5));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Dni:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, -1, -1));

        txtApellidos.setBackground(new java.awt.Color(0, 0, 0));
        txtApellidos.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtApellidos.setForeground(new java.awt.Color(255, 255, 255));
        txtApellidos.setBorder(null);
        txtApellidos.setCaretColor(new java.awt.Color(255, 255, 255));
        jPanel2.add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 210, 30));

        txtId.setEditable(false);
        txtId.setBackground(new java.awt.Color(0, 0, 0));
        txtId.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtId.setForeground(new java.awt.Color(255, 255, 255));
        txtId.setBorder(null);
        txtId.setCaretColor(new java.awt.Color(255, 255, 255));
        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });
        jPanel2.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 0, 90, 30));

        txtNombres.setBackground(new java.awt.Color(0, 0, 0));
        txtNombres.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtNombres.setForeground(new java.awt.Color(255, 255, 255));
        txtNombres.setBorder(null);
        txtNombres.setCaretColor(new java.awt.Color(255, 255, 255));
        jPanel2.add(txtNombres, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 150, 210, 30));

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Id:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, -1, -1));

        txtDni.setEditable(false);
        txtDni.setBackground(new java.awt.Color(0, 0, 0));
        txtDni.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtDni.setForeground(new java.awt.Color(255, 255, 255));
        txtDni.setBorder(null);
        txtDni.setCaretColor(new java.awt.Color(255, 255, 255));
        jPanel2.add(txtDni, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, 140, 30));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Apellidos:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, -1, -1));

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nombres:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, -1, -1));

        jSeparator2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 30, 80, 10));
        jPanel2.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 180, 20));

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Email:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, -1, -1));

        txtEmail.setBackground(new java.awt.Color(0, 0, 0));
        txtEmail.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtEmail.setForeground(new java.awt.Color(255, 255, 255));
        txtEmail.setBorder(null);
        txtEmail.setCaretColor(new java.awt.Color(255, 255, 255));
        jPanel2.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 200, 210, 30));

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Usuario:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, -1, -1));

        txtNomUsuario.setBackground(new java.awt.Color(0, 0, 0));
        txtNomUsuario.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtNomUsuario.setForeground(new java.awt.Color(255, 255, 255));
        txtNomUsuario.setBorder(null);
        txtNomUsuario.setCaretColor(new java.awt.Color(255, 255, 255));
        jPanel2.add(txtNomUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 250, 210, 30));

        jSeparator3.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, 130, 20));
        jPanel2.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 180, 10));

        jSeparator5.setBackground(new java.awt.Color(160, 160, 160));
        jSeparator5.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, 230, 20));
        jPanel2.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, 180, 20));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 102, 102));
        jLabel9.setText("Estado:");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 420, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 102, 102));
        jLabel8.setText("Tipo de Usuario:");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, -1, -1));

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Contraseña:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, -1, -1));

        txtClave.setBackground(new java.awt.Color(0, 0, 0));
        txtClave.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtClave.setForeground(new java.awt.Color(255, 255, 255));
        txtClave.setBorder(null);
        txtClave.setCaretColor(new java.awt.Color(255, 255, 255));
        jPanel2.add(txtClave, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, 210, 30));

        txtTipoUser.setEditable(false);
        txtTipoUser.setBackground(new java.awt.Color(0, 0, 0));
        txtTipoUser.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtTipoUser.setForeground(new java.awt.Color(255, 255, 255));
        txtTipoUser.setBorder(null);
        txtTipoUser.setCaretColor(new java.awt.Color(255, 255, 255));
        jPanel2.add(txtTipoUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 350, 210, 30));

        txtEstado.setEditable(false);
        txtEstado.setBackground(new java.awt.Color(0, 0, 0));
        txtEstado.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtEstado.setForeground(new java.awt.Color(0, 102, 102));
        txtEstado.setBorder(null);
        txtEstado.setCaretColor(new java.awt.Color(255, 255, 255));
        txtEstado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEstadoActionPerformed(evt);
            }
        });
        jPanel2.add(txtEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 410, 210, 30));
        jPanel2.add(jSeparator11, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 330, 180, 10));

        jSeparator12.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.add(jSeparator12, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 380, 170, 10));

        jSeparator13.setBackground(new java.awt.Color(0, 51, 51));
        jSeparator13.setForeground(new java.awt.Color(0, 102, 102));
        jPanel2.add(jSeparator13, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 380, 10, 20));

        jSeparator14.setBackground(new java.awt.Color(0, 51, 51));
        jSeparator14.setForeground(new java.awt.Color(0, 102, 102));
        jPanel2.add(jSeparator14, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 440, 130, 20));

        jSeparator7.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 440, 50, 20));

        jLabel10.setBackground(new java.awt.Color(51, 255, 255));
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fon2_1.jpg"))); // NOI18N
        jLabel10.setText("jLabel10");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -20, 360, 540));

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 60, 360, 500);

        jPanel3.setBackground(new java.awt.Color(0, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btnModificar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/modificar_1.png"))); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnImprimir.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnImprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/print.png"))); // NOI18N
        btnImprimir.setText("Imprimir");
        btnImprimir.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnModificar)
                    .addComponent(btnImprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(btnModificar)
                .addGap(18, 18, 18)
                .addComponent(btnImprimir)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3);
        jPanel3.setBounds(470, 350, 143, 121);

        btnCancelar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/canc_1.png"))); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCancelar);
        btnCancelar.setBounds(480, 490, 130, 37);

        jpAdmin.setkEndColor(new java.awt.Color(0, 204, 255));
        jpAdmin.setkGradientFocus(50);
        jpAdmin.setkStartColor(new java.awt.Color(0, 102, 102));
        jpAdmin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtImagen.setBackground(new java.awt.Color(255, 255, 255));
        txtImagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/add1.jpg"))); // NOI18N
        jpAdmin.add(txtImagen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 200, 210));

        getContentPane().add(jpAdmin);
        jpAdmin.setBounds(440, 70, 210, 220);

        jpInvitado.setkEndColor(new java.awt.Color(0, 204, 255));
        jpInvitado.setkGradientFocus(50);
        jpInvitado.setkStartColor(new java.awt.Color(0, 102, 102));
        jpInvitado.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtImagen1.setBackground(new java.awt.Color(255, 255, 255));
        txtImagen1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/inv.jpg"))); // NOI18N
        jpInvitado.add(txtImagen1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 193, 202));

        getContentPane().add(jpInvitado);
        jpInvitado.setBounds(430, 70, 210, 220);

        jPanel1.setBackground(new java.awt.Color(0, 255, 255));

        jLabel28.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Administrar Perfil");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(244, 244, 244)
                .addComponent(jLabel28)
                .addContainerGap(263, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel28)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 720, 60);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fon4.jpg"))); // NOI18N
        getContentPane().add(jLabel11);
        jLabel11.setBounds(360, 40, 340, 540);

        pack();
    }

    private void btnImagenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImagenActionPerformed
        // TODO add your handling code here:
        try {
            open();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

    }//GEN-LAST:event_btnImagenActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        //VALIDAR CAMPOS PARA QUE TODOS ESTEN LLENOS
        if (txtApellidos.getText().isEmpty() || txtNombres.getText().isEmpty()
                || txtEmail.getText().isEmpty() || txtNomUsuario.getText().isEmpty()
                || txtClave.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor rellene todos los campos");

        } else {

            String idUsuario = txtId.getText();
            String Nombres = txtNombres.getText();
            String Apellidos = txtApellidos.getText();
            String Dni = txtDni.getText();
            String Email = txtEmail.getText();
            String Usuario = txtNomUsuario.getText();
            String Clave = txtClave.getText();
            String TipoUsuario = txtTipoUser.getText();
//            String Foto = txtImagen.getText();
            String Estado = txtEstado.getText();

            if (nums == 0) {

                int respuesta = metodos.ActualizarUsuarios(idUsuario,Nombres,Apellidos,Dni ,Email, Usuario, Clave, TipoUsuario, Estado);
                if (respuesta > 0) {
                    nums = 0;
                }
            }
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        dispose();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirActionPerformed
        JRReporte cr = new JRReporte();
        Connection con = null; 
        try {
                con = ConexionBD.conectar();
                Map parametros = new HashMap();
                parametros.put("Id", txtId.getText());
                String ruta = System.getProperty("user.dir") + "\\src\\Reportes\\Perfil.jrxml";
                cr.abrirReporte(ruta, con, parametros);
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al cargar el reporte de Empleados", "ERROR", JOptionPane.ERROR_MESSAGE);

            }
    }//GEN-LAST:event_btnImprimirActionPerformed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    private void txtEstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEstadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEstadoActionPerformed
    void open() throws IOException {
      
        JFileChooser JFC = new JFileChooser();
       
        JFC.setFileFilter(new FileNameExtensionFilter("todos los archivos *.jpg", "png", "JPG","JPEG"));
       
        int abrir = JFC.showDialog(null, "Abrir");
        if (abrir == JFileChooser.APPROVE_OPTION) {
            FileReader FR = null;
            BufferedReader BR = null;

            try {
                File archivo = JFC.getSelectedFile();

                String PATH = JFC.getSelectedFile().getAbsolutePath();
                if (PATH.endsWith(".jpg") || PATH.endsWith(".png") || PATH.endsWith(".jpeg")) {

                    FR = new FileReader(archivo);
                    BR = new BufferedReader(FR);

                    String linea;
                    if (path.compareTo(archivo.getAbsolutePath()) == 0) {
                        System.out.println("Archivo Abierto" + "Oops! Error" + JOptionPane.ERROR_MESSAGE);
                    } else {
                        path = archivo.getAbsolutePath();
                        while ((linea = BR.readLine()) != null) { 
                            ;
                        }
                    }
                    txtImagen.setIcon(new ImageIcon(path));
                    ImageIcon icon = new ImageIcon(path);
                    Image img = icon.getImage();
                    Image newimg = img.getScaledInstance(txtImagen.getWidth(), txtImagen.getHeight(), java.awt.Image.SCALE_SMOOTH);
                    ImageIcon newIcon = new ImageIcon(newimg);
                    txtImagen.setIcon(newIcon);
                    txtImagen.setSize(txtImagen.getWidth(), txtImagen.getHeight());

                } else {
                    System.out.println("Archivo no soportado" + "Oops! Error" + JOptionPane.ERROR_MESSAGE);
                    open();
                }

            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
                
            } finally {
                try {
                    if (null != FR) {
                        FR.close();
                    }

                } catch (IOException ex) {
                    ex.printStackTrace();
                    
                }
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnImagen;
    private javax.swing.JButton btnImprimir;
    private javax.swing.JButton btnModificar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    public static javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator14;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    public static keeptoo.KGradientPanel jpAdmin;
    public static keeptoo.KGradientPanel jpInvitado;
    public static javax.swing.JTextField txtApellidos;
    public static javax.swing.JTextField txtClave;
    public static javax.swing.JTextField txtDni;
    public static javax.swing.JTextField txtEmail;
    public static javax.swing.JTextField txtEstado;
    public static javax.swing.JTextField txtId;
    public static javax.swing.JLabel txtImagen;
    public static javax.swing.JLabel txtImagen1;
    public static javax.swing.JTextField txtNomUsuario;
    public static javax.swing.JTextField txtNombres;
    public static javax.swing.JTextField txtTipoUser;
    // End of variables declaration//GEN-END:variables
}
