
package Vista;

//import Conexion.ConexionBD;


public class Principal {

    public static void main(String[] args) {
       frmLogin.main(args);
       
       //ConexionBD cn = new ConexionBD();
       //ConexionBD.conectar();
    }
    
}
